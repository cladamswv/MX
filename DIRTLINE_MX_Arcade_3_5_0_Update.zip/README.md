# DIRTLINE MX Arcade 3.5.0

An arcade motocross racer for Android landscape, built with Godot 4.3 and the GL Compatibility renderer.

3.5.0 is the controller-and-grounding update: a left virtual joystick now handles steering and lean, Brake / Boost / Throttle use round face buttons, CharacterBody track collision is disabled so sampled surface-following remains authoritative, and the logo/loading/menu art has a restrained retro pixel treatment. It retains the 3.4.0 audio, graphics, scoring, garage, and GitHub build pipeline.

Open this folder in Godot 4.3. Run `python3 tools/full_audit.py`, then press Play or export Android. The repository workflow performs the audit, Godot import, runtime smoke test, Android debug export, APK signature verification, and manifest checks.

```bash
python3 tools/full_audit.py
godot --headless --path . --import
godot --headless --path . --script res://tests/Regression.gd
```

Generated audio is original synthesis authored by `tools/compose_audio.py`; no third-party recordings are included. The included DejaVu Sans Bold font license is in `ui/fonts/LICENSE.txt`.
