# DIRTLINE MX Arcade 3.5.0

- Replaced the old touch cluster with a left virtual joystick plus round Brake / Boost / Throttle face buttons.
- Added continuous touch steering and joystick lean / airborne pitch control with a center dead zone.
- Removed CharacterBody track collision from race movement so authored surface-following is authoritative and cannot sink/pop against the trimesh.
- Raised the grounded ride offset slightly for cleaner tire contact.
- Added a subtle pixel-art treatment to the logo, loading art, and menu art.
- Updated regression checks for the new controls and anti-sink grounding contract.

# DIRTLINE MX Arcade 3.3.0

## 3.3.0 - Arcade handling + clear-screen rebuild

- Replaced road-dependent `move_and_slide()` racing with deterministic arcade surface-follow movement.
- Player and AI now advance predictably every physics frame while still supporting lane changes, jumps, wheelies, landing pitch, mud, boost, crashes and finish logic.
- Camera now trails the rider instead of sitting ahead of the bike, keeping the player visible and leaving usable look-ahead.
- Removed the 512x512 gameplay logo texture that was expanding to native size on Android and blocking the left half of the screen.
- Added compact text branding and a smaller top HUD.
- Reduced bottom control-pad footprint while retaining large touch targets.
- Front-end TextureRects now set expand mode before assigned size to avoid texture minimum-size regressions.
- Smoke test now requires meaningful player and AI forward displacement, compact HUD dimensions, race-track binding and camera-behind-player staging.

This is a behavior-focused rebuild rather than another visual-only patch.
